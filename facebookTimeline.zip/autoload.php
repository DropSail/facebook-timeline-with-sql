<?php

date_default_timezone_set('asia/dhaka');

// include functions
if (file_exists(__DIR__ . '/app/functions.php')) {
    require_once __DIR__ . '/app/functions.php';
}
